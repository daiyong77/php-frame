<?php

namespace Controller\Cmd;

class Index extends \Controller\Common
{
    public function index()
    {
        $this->echo('测试输出成功');
    }
}
