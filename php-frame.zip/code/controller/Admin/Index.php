<?php

namespace Controller\Admin;

class Index extends \Controller\Common
{
    public function index()
    {
        $this->success();
    }
}
